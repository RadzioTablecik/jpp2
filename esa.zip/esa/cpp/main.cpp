#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>

class Gf {
private:
    unsigned long long value;
    unsigned long long ORDER = 7;
    unsigned long long characteristic;

    unsigned long long checkPrimeExt() const {
        unsigned long long n = ORDER;
        std::vector<unsigned long long> primes;
        unsigned long long k = 2;

        while (n > 1 && k <= sqrt(n)) {
            while (n % k == 0) {
                primes.push_back(k);
                if (primes[0] != k) {
                    throw std::runtime_error("Nieprawidłowe ciało GF(q) - liczba q nie jest potęgą liczby pierwszej");
                }
                n /= k;
            }
            k++;
        }

        if (n > 1 && !primes.empty()) {
            throw std::runtime_error("Nieprawidłowe ciało GF(q) - liczba q nie jest potęgą liczby pierwszej");
        } else {
            primes.push_back(n);
        }

        return primes[0];
    }

    Gf inv() const {
        long long t = 0;
        long long newt = 1;
        long long r = ORDER;
        long long newr = static_cast<long long>(value);
        while (newr != 0) {
            long long quotient = r / newr;
            long long tmp = newt;
            newt = t - quotient * newt;
            t = tmp;
            tmp = newr;
            newr = r - quotient * newr;
            r = tmp;
        }
        if (r > 1) {
            throw std::runtime_error("Liczba jest nieodwracalna w ciele");
        }
        if (t < 0) {
            t += ORDER;
        }
        return Gf(t);
    }

public:
    Gf(unsigned long long value){
        this->characteristic = checkPrimeExt();
        this->value = value%ORDER;
    }

    unsigned long long getValue() const {
        return value;
    }

    unsigned long long getCharacteristic() const{
        return characteristic;
    }

    friend bool operator==(const Gf& lhs, const Gf& rhs) {
        return lhs.value == rhs.value;
    }

    friend bool operator!=(const Gf& lhs, const Gf& rhs) {
        return !(lhs == rhs);
    }

    friend bool operator<(const Gf& lhs, const Gf& rhs) {
        return lhs.value < rhs.value;
    }

    friend bool operator<=(const Gf& lhs, const Gf& rhs) {
        return lhs.value <= rhs.value;
    }

    friend bool operator>(const Gf& lhs, const Gf& rhs) {
        return lhs.value > rhs.value;
    }

    friend bool operator>=(const Gf& lhs, const Gf& rhs) {
        return lhs.value >= rhs.value;
    }

    friend std::ostream& operator<<(std::ostream& os, const Gf& gf) {
        return os << gf.value;
    }

    Gf operator+(const Gf& other) const {
        return Gf((value + other.value) % ORDER);
    }

    Gf& operator+=(const Gf& other) {
        value = (value + other.value) % ORDER;
        return *this;
    }

    Gf operator-(const Gf& other) const {
        return Gf((value + ORDER - other.value) % ORDER);
    }

    Gf& operator-=(const Gf& other) {
        value = (value + ORDER - other.value) % ORDER;
        return *this;
    }

    Gf operator*(const Gf& other) const {
        return Gf((value * other.value) % ORDER);
    }

    Gf& operator*=(const Gf& other) {
        value = (value * other.value) % ORDER;
        return *this;
    }

    Gf operator/(const Gf& other) const {
        return *this * other.inv();
    }

    Gf& operator/=(const Gf& other) {
        *this *= other.inv();
        return *this;
    }
};

int main() {
    Gf a(6);
    Gf b(3);
    Gf c = a + b;
    std::cout << c.getValue() << std::endl;
    c = a - b;
    std::cout << c.getValue() << std::endl;
    c = a * b;
    std::cout << c.getValue() << std::endl;
    Gf d = a / b;
    std::cout << d.getValue() << std::endl;

    std::cout<<d.getCharacteristic()<<std::endl;
    return 0;
}
