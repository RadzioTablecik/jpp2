import java.util.ArrayList;
import java.math.BigInteger;

public class Main {
    public static void main(String[] args) {
        Gf a = new Gf(BigInteger.valueOf(6));
        Gf b = new Gf(BigInteger.valueOf(3));
        Gf c = a.add(b);
        System.out.println(c.getValue());
        c = a.subtract(b);
        System.out.println(c.getValue());
        c = a.multiply(b);
        System.out.println(c.getValue());
        Gf d = a.divide(b);
        System.out.println(d.getValue());

        System.out.println(d.getCharacteristic());
    }
}