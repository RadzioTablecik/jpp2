import java.math.BigInteger;
import java.util.ArrayList;

public class Gf {
    private BigInteger value;
    private static final BigInteger ORDER = BigInteger.valueOf(7);
    private BigInteger characteristic;

    private BigInteger checkPrimeExt() {
        BigInteger n = ORDER;
        ArrayList<BigInteger> primes = new ArrayList<>();
        BigInteger k = BigInteger.valueOf(2);

        while (n.compareTo(BigInteger.ONE) > 0 && k.compareTo(n.sqrt()) <= 0) {
            while (n.mod(k).equals(BigInteger.ZERO)) {
                primes.add(k);
                if (!primes.get(0).equals(k)) {
                    throw new RuntimeException("Nieprawidłowe ciało GF(q) - liczba q nie jest potęgą liczby pierwszej");
                }
                n = n.divide(k);
            }
            k = k.add(BigInteger.ONE);
        }

        if (n.compareTo(BigInteger.ONE) > 0 && !primes.isEmpty()) {
            throw new RuntimeException("Nieprawidłowe ciało GF(q) - liczba q nie jest potęgą liczby pierwszej");
        } else {
            primes.add(n);
        }

        return primes.get(0);
    }

    private Gf inv() {
        BigInteger t = BigInteger.ZERO;
        BigInteger newt = BigInteger.ONE;
        BigInteger r = ORDER;
        BigInteger newr = value;
        while (!newr.equals(BigInteger.ZERO)) {
            BigInteger quotient = r.divide(newr);
            BigInteger tmp = newt;
            newt = t.subtract(quotient.multiply(newt));
            t = tmp;
            tmp = newr;
            newr = r.subtract(quotient.multiply(newr));
            r = tmp;
        }
        if (r.compareTo(BigInteger.ONE) > 0) {
            throw new RuntimeException("Liczba jest nieodwracalna w ciele");
        }
        if (t.compareTo(BigInteger.ZERO) < 0) {
            t = t.add(ORDER);
        }
        return new Gf(t);
    }

    public Gf(BigInteger value) {
        this.characteristic = checkPrimeExt();
        this.value = value.mod(ORDER);
    }

    public BigInteger getValue() {
        return value;
    }

    public BigInteger getCharacteristic() {
        return characteristic;
    }

    public boolean equals(Gf other) {
        return this.value.equals(other.value);
    }

    public boolean lessThan(Gf other) {
        return this.value.compareTo(other.value) < 0;
    }

    public boolean lessThanOrEqual(Gf other) {
        return this.value.compareTo(other.value) <= 0;
    }

    public boolean greaterThan(Gf other) {
        return this.value.compareTo(other.value) > 0;
    }

    public boolean greaterThanOrEqual(Gf other) {
        return this.value.compareTo(other.value) >= 0;
    }

    public Gf add(Gf other) {
        return new Gf((value.add(other.value)).mod(ORDER));
    }

    public Gf subtract(Gf other) {
        return new Gf((value.add(ORDER).subtract(other.value)).mod(ORDER));
    }

    public Gf multiply(Gf other) {
        return new Gf((value.multiply(other.value)).mod(ORDER));
    }

    public Gf divide(Gf other) {
        return this.multiply(other.inv());
    }

}
