import math

class Gf:
    _ORDER = 7

    def __init__(self, value):
        self._characteristic = self._checkPrimeExt()
        self._value = value % self._ORDER

    def _checkPrimeExt(self):
        n = self._ORDER
        primes = []
        k = 2

        while n > 1 and k <= math.sqrt(n):
            while n % k == 0:
                primes.append(k)
                if primes[0] != k:
                    raise ValueError("Nieprawidłowe ciało GF(q) - liczba q nie jest potęgą liczby pierwszej")
                n /= k
            k += 1

        if n > 1 and primes:
            raise ValueError("Nieprawidłowe ciało GF(q) - liczba q nie jest potęgą liczby pierwszej")
        else:
            primes.append(n)

        return primes[0]

    def _inv(self):
        t = 0
        newt = 1
        r = self._ORDER
        newr = self._value
        while newr != 0:
            quotient = r // newr
            t, newt = newt, t - quotient * newt
            r, newr = newr, r - quotient * newr
        if r > 1:
            raise ValueError("Liczba jest nieodwracalna w ciele")
        if t < 0:
            t += self._ORDER
        return Gf(t)

    def getValue(self):
        return self._value

    def getCharacteristic(self):
        return self._characteristic

    def __eq__(self, other):
        return self._value == other._value

    def __lt__(self, other):
        return self._value < other._value

    def __le__(self, other):
        return self._value <= other._value

    def __gt__(self, other):
        return self._value > other._value

    def __ge__(self, other):
        return self._value >= other._value

    def __add__(self, other):
        return Gf((self._value + other._value) % self._ORDER)

    def __sub__(self, other):
        return Gf((self._value + self._ORDER - other._value) % self._ORDER)

    def __mul__(self, other):
        return Gf((self._value * other._value) % self._ORDER)

    def __truediv__(self, other):
        return self * other._inv()

    def __str__(self):
        return str(self._value)


if __name__ == "__main__":
    a = Gf(6)
    b = Gf(3)
    c = a + b
    print(c.getValue())
    c = a - b
    print(c.getValue())
    c = a * b
    print(c.getValue())
    d = a / b
    print(d.getValue())

    print(d.getCharacteristic())